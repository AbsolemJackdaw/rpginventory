/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgMageSet;

/**
 *
 * @author Home
 */
public class MSCommonProxy {
    public void registerRendering(){
        
    }
}
