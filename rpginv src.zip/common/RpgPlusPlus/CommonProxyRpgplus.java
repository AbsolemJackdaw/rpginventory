package RpgPlusPlus;


public class CommonProxyRpgplus {

    public void registerRenderInformation() {
        //tick registered both sides behind an EFFECTIVE check
        //So integrated server will register too.
    }

  
}
