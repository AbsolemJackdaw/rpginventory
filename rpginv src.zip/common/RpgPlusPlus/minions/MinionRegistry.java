/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgPlusPlus.minions;

import java.util.HashMap;
import java.util.List;

/**
 *
 * @author Home
 */
public class MinionRegistry {
    public static HashMap<String, List<IMinion>> playerMinions = new HashMap();
}
