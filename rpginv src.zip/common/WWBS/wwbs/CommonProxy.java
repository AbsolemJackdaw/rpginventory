package WWBS.wwbs;

import net.minecraft.entity.player.EntityPlayer;

public class CommonProxy  {

	public void openGui(int id, EntityPlayer p) {
		
	}

}
