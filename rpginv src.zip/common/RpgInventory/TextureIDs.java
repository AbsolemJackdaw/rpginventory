/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgInventory;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderEngine;
import net.minecraftforge.client.MinecraftForgeClient;

/**
 *
 * @author Richard Smith <rich1051414@gmail.com>
 */
public class TextureIDs {

    private static final String texForgeGuiName = "/subaraki/Forge.png";
    private static final String texRpgInvTMName = "/subaraki/RPGinventoryTM.png";
    private static final String texBookGuiName = "/subaraki/bookgui.png";
    //FontRenderer doesnt reset it's texture properly, so we will keep an ID.
    private static final String defaultfont = "/font/default.png";
    public static int texForgeGuiID;
    public static int texRpgInvTMID;
    public static int texBookGuiID;
    public static int defaultfontID;
    private static boolean runonce = false;

    public static void init() {
        RenderEngine engine = Minecraft.getMinecraft().renderEngine;
        if (!runonce) {
            runonce = true;
            texForgeGuiID = engine.getTexture(texForgeGuiName);
            texRpgInvTMID = engine.getTexture(texRpgInvTMName);
            texBookGuiID = engine.getTexture(texBookGuiName);
            defaultfontID = engine.getTexture(defaultfont);
        }
    }
}
