package RpgInventory.forge;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.util.Random;

import cpw.mods.fml.common.network.PacketDispatcher;

import RpgInventory.mod_RpgInventory;

import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.packet.Packet250CustomPayload;
import net.minecraft.src.ModLoader;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockForge extends BlockContainer {

	public BlockForge(int par1, Material par2Material) {
		super(par1, par2Material);
		this.setCreativeTab(mod_RpgInventory.tab);
	}

	private static boolean keepInventory = false;

	//TEXTUREN
	public static int temoldOvenBottom = 82;
	public static int temoldOvenTop =82;
	public static int temoldOvenSide = 82;
	public static int temoldOvenFront = 80;
	private int temoldOvenFrontActive = 81;


	/**
	 * Is the random generator used by furnace to drop the inventory contents in random directions.
	 */
	private Random temoldRand;

	@Override
	public TileEntity createNewTileEntity(World world)
	{
		return new TEMold();
	}

	/**
	 * Called whenever the block is added into the world. Args: world, x, y, z
	 */
	public void onBlockAdded(World par1World, int x, int y, int z)
	{
		super.onBlockAdded(par1World, x, y, z);
		setDefaultDirection(par1World, x, y, z);
		par1World.markBlockForUpdate(x, y, z);
	}

	/**
	 * set a blocks direction
	 */
	private void setDefaultDirection(World par1World, int x, int y, int z)
	{
		TileEntity blockEntity = par1World.getBlockTileEntity(x, y, z);
		if (par1World.isRemote)
		{
			return;
		}

		int i = par1World.getBlockId(x, y, z - 1);
		int j = par1World.getBlockId(x, y, z + 1);
		int k = par1World.getBlockId(x - 1, y, z);
		int l = par1World.getBlockId(x + 1, y, z);
		byte byte0 = 3;

		if (Block.opaqueCubeLookup[i] && !Block.opaqueCubeLookup[j])
		{
			byte0 = 3;
		}
		if (Block.opaqueCubeLookup[j] && !Block.opaqueCubeLookup[i])
		{
			byte0 = 2;
		}
		if (Block.opaqueCubeLookup[k] && !Block.opaqueCubeLookup[l])
		{
			byte0 = 5;
		}
		if (Block.opaqueCubeLookup[l] && !Block.opaqueCubeLookup[k])
		{
			byte0 = 4;
		}
		((TEMold)blockEntity).setFrontDirection(byte0);
	}

	/**
	 * Retrieves the block texture to use based on the display side. Args: iBlockAccess, x, y, z, side
	 */
	public int getBlockTexture(IBlockAccess access, int x, int y, int z, int side)
	{
		int front = 0;

		TileEntity tile = Minecraft.getMinecraft().getIntegratedServer().worldServers[0].getBlockTileEntity(x, y, z);

		if(tile != null)
		{
			front = ((TEMold)tile).getFrontDirection();
		}
		else
		{
			Minecraft.getMinecraft().getIntegratedServer().worldServers[0].markBlockForUpdate(x, y, z);
		}

		switch(side)
		{
		case 0: return temoldOvenBottom;
		case 1: return temoldOvenTop;
		default :
			if(side == front)
			{
				return ((TEMold)tile).isActive() ? temoldOvenFrontActive : temoldOvenFront;
			}
			else
			{
				return temoldOvenSide;
			}

		}
	}

	/**
	 * Returns the block texture based on the side being looked at. Args: side
	 */
	public int getBlockTextureFromSide(int side)
	{
		switch(side)
		{
		case 0:
			return temoldOvenBottom; 
		case 1:
			return temoldOvenTop;
		case 2:
			return temoldOvenSide;
		case 3:
			return temoldOvenFront;
		case 4:
			return temoldOvenSide;
		case 5:
			return temoldOvenSide;
		default : return 0;
		}
	}

	/**
	 * called everytime the player right clicks this block
	 */
	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int i2, float a, float b, float c)
	{
		System.out.println("activating Mold Forge");
		int i = 8;
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		ObjectOutput out;
		DataOutputStream outputStream = new DataOutputStream(bytes);
		try {
			outputStream.writeInt(i);
			Packet250CustomPayload packet = new Packet250CustomPayload("RpgInv", bytes.toByteArray());
			PacketDispatcher.sendPacketToServer(packet);
			System.out.println("Block Packet send");
		} catch (IOException e) {
			e.printStackTrace();
		}		return true;
	}

	/**
	 * Called when the block is placed in the world.
	 */
	@Override
	public void onBlockPlacedBy(World w, int x, int y, int z, EntityLiving entity)
	{
		int var = MathHelper.floor_double((double)(entity.rotationYaw *4.0F / 360.0F) + 0.5D) & 3;

		TileEntity blockEntity = (TileEntity) w.getBlockTileEntity(x, y, z);
		switch(var)
		{
		case 0: ((TEMold)blockEntity).setFrontDirection(2);break;

		case 1: ((TEMold)blockEntity).setFrontDirection(5);break;

		case 2: ((TEMold)blockEntity).setFrontDirection(3);break;

		case 3: ((TEMold)blockEntity).setFrontDirection(4);break;

		}

	}

	/**
	 * ejects contained items into the world, and notifies neighbours of an update, as appropriate
	 */
	public void breakBlock(World par1World, int par2, int par3, int par4, int par5, int par6)
	{
		if (!keepInventory)
		{
			TEMold temold = (TEMold)par1World.getBlockTileEntity(par2, par3, par4);
			if (temold != null)
			{
				for (int var8 = 0; var8 < temold.getSizeInventory(); ++var8)
				{
					ItemStack item = temold.getStackInSlot(var8);
					if (item != null)
					{
						float var10 = this.temoldRand.nextFloat() * 0.8F + 0.1F;
						float var11 = this.temoldRand.nextFloat() * 0.8F + 0.1F;
						float var12 = this.temoldRand.nextFloat() * 0.8F + 0.1F;
						while (item.stackSize > 0)
						{
							int var13 = this.temoldRand.nextInt(21) + 10;
							if (var13 > item.stackSize)
							{
								var13 = item.stackSize;
							}
							item.stackSize -= var13;
							EntityItem var14 = new EntityItem(par1World, (double)((float)par2 + var10), (double)((float)par3 + var11), (double)((float)par4 + var12), new ItemStack(item.itemID, var13, item.getItemDamage()));
							if (item.hasTagCompound())
							{
								var14.getEntityItem().setTagCompound((NBTTagCompound)item.getTagCompound().copy());
							}
							float var15 = 0.05F;
							var14.motionX = (double)((float)this.temoldRand.nextGaussian() * var15);
							var14.motionY = (double)((float)this.temoldRand.nextGaussian() * var15 + 0.2F);
							var14.motionZ = (double)((float)this.temoldRand.nextGaussian() * var15);
							par1World.spawnEntityInWorld(var14);
						}
					}
				}
			}
		}
		super.breakBlock(par1World, par2, par3, par4, par5, par6);
	}

	public String getTextureFile() {
		return "/subaraki/RPGinventoryTM.png";
	}
}

