package RpgInventory.forge;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.StatCollector;

import org.lwjgl.opengl.GL11;
public class GuiMF extends GuiContainer
{
	private TEMold forgeInventory;

	public GuiMF(InventoryPlayer inventory, TEMold te)
	{
		super(new MoldContainer(inventory, te));
		forgeInventory = te;
		this.xSize = 176;
		this.ySize = 184;
	}

	/**
	 * Draw the foreground layer for the GuiContainer (everythin in front of the items)
	 */
	protected void drawGuiContainerForegroundLayer(int par1, int par2)
	{
		fontRenderer.drawString(StatCollector.translateToLocal("container.inventory"), 8, (ySize - 96) + 2, 0xffffff);
		fontRenderer.drawString(StatCollector.translateToLocal("Mold Forge"), 8, (ySize -5) + 2, 0xffffff);

		
	}

	/**
	 * Draw the background layer for the GuiContainer (everything behind the items)
	 */
	protected void drawGuiContainerBackgroundLayer(float par1, int par2, int par3)
	{
		
		int i = mc.renderEngine.getTexture("/subaraki/Forge.png");
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(i);
		int j = (width - xSize) / 2;
		int k = (height - ySize) / 2;
		drawTexturedModalRect(j, k, 0, 0, xSize, ySize);

		if (forgeInventory.isCombining())
		{
			int burn = forgeInventory.getTimeRemainingScaled(i);
			drawTexturedModalRect(221, 33, 176, 0, burn, 10);
		}

		int update = forgeInventory.getProgressScaled(i);
		drawTexturedModalRect(231, 48, 176, 32,-update , -update);
	}
}