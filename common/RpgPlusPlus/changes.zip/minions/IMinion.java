/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgPlusPlus.minions;

/**
 *
 * @author Home
 */
public interface IMinion {
    public void Harvest();
}
