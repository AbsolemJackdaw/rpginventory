/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgPlusPlus;

import RpgInventory.CommonTickHandler;
import RpgInventory.gui.inventory.RpgInventory;
import RpgInventory.mod_RpgInventory;
import RpgPlusPlus.minions.EntityMinionS;
import RpgPlusPlus.minions.EntityMinionZ;
import RpgPlusPlus.minions.IMinion;
import RpgPlusPlus.minions.MinionRegistry;
import cpw.mods.fml.common.network.IPacketHandler;
import cpw.mods.fml.common.network.Player;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.INetworkManager;
import net.minecraft.network.packet.Packet250CustomPayload;
import net.minecraft.world.World;

/**
 *
 * @author Home
 */
public class RpgPlusPacketHandler implements IPacketHandler {

    @Override
    public void onPacketData(INetworkManager manager, Packet250CustomPayload packet, Player player) {
        //
        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(packet.data));
        int weaponID = 0;
        EntityPlayer p = (EntityPlayer) player;
        try {
            weaponID = dis.readInt();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        ItemStack item = p.getCurrentEquippedItem();
        ItemStack var3 = p.inventory.armorItemInSlot(3);
        ItemStack var2 = p.inventory.armorItemInSlot(2);
        ItemStack var1 = p.inventory.armorItemInSlot(1);
        ItemStack var0 = p.inventory.armorItemInSlot(0);
        if (item != null && var3 != null && var2 != null && var1 != null && var0 != null) {
            Item item4 = var3.getItem();
            Item item11 = var2.getItem();
            Item item2 = var1.getItem();
            Item item3 = var0.getItem();
            switch (weaponID) {
                case WEAPONIDS.SKULLRCLICK:
                    int minionType = 0;
                    try {
                        dis.close();
                    } catch (Throwable ex) {
                        ex.printStackTrace();
                    }
                    if (item.getItem().equals(mod_RpgPlus.necro_weapon) && item4.equals(mod_RpgPlus.necroHood) && item11.equals(mod_RpgPlus.necroChestplate) && item2.equals(mod_RpgPlus.necroLeggings) && item3.equals(mod_RpgPlus.necroBoots)) {
                        if (!CommonTickHandlerRpgPlus.rpgPluscooldownMap.containsKey(p.username)) {
                            CommonTickHandlerRpgPlus.rpgPluscooldownMap.put(p.username, 0);
                        }
                        if (CommonTickHandlerRpgPlus.rpgPluscooldownMap.get(p.username) <= 0) {
                            //2 second cooldown
                            CommonTickHandlerRpgPlus.rpgPluscooldownMap.put(p.username, 20 * 2);
                            //System.out.println("SpawnMob");
                            //Allow staff/hammer to perform one last aoe then break the weapon if its damaged enough.
                            if (item.getItemDamage() + 2 >= item.getMaxDamage()) {
                                //Trigger item break stuff
                                item.damageItem(item.getMaxDamage() - item.getItemDamage() + 1, p);
                                //delete the item
                                p.renderBrokenItemStack(item);
                                p.setCurrentItemOrArmor(0, (ItemStack) null);
                            } else {
                                item.damageItem(2, p);
                            }
                            RpgInventory rpg = mod_RpgInventory.proxy.getInventory(p.username);
                            ItemStack shield = rpg.getJewelInSlot(1);
                            World world = p.worldObj;
                            if (shield != null && shield.getItem() == mod_RpgPlus.necro_shield) {
                                if (!world.isRemote) {
                                    EntityMinionS var4 = new EntityMinionS(world, p);

                                    if (var4 != null) {
                                        var4.setPosition(p.posX, p.posY, p.posZ);
                                        world.spawnEntityInWorld(var4);
                                        var4.setTamed(true);
                                        var4.setOwner(p.username);
                                    }
                                }
                            } else {
                                if (!world.isRemote) {
                                    EntityMinionZ var4 = new EntityMinionZ(world, p);

                                    if (var4 != null) {
                                        var4.setPosition(p.posX, p.posY, p.posZ);
                                        world.spawnEntityInWorld(var4);
                                        var4.setTamed(true);
                                        var4.setOwner(p.username);
                                    }
                                }
                            }
                        } else {
                            p.sendChatToPlayer("You must wait for energy to replenish, left: " + Math.floor(1 + CommonTickHandlerRpgPlus.rpgPluscooldownMap.get(p.username) / 20) + " seconds");
                        }

                    }
                    break;
                case 6:
                    if (item.getItem().equals(mod_RpgPlus.necro_weapon) && item4.equals(mod_RpgPlus.necroHood) && item11.equals(mod_RpgPlus.necroChestplate) && item2.equals(mod_RpgPlus.necroLeggings) && item3.equals(mod_RpgPlus.necroBoots)) {
                        if(MinionRegistry.playerMinions.containsKey(p.username)){
                            List<IMinion> list = MinionRegistry.playerMinions.get(p.username);
                            for(IMinion minion: list){
                                minion.Harvest();
                            }
                        }
                    }
                default:
                    break;
            }
        }
    }

    public static class WEAPONIDS {

        public static final int SKULLRCLICK = 5;
        public static final int SPECIAL = 6;
    }
}
