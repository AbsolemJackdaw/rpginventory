/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgInventory;

import RpgInventory.gui.inventory.RpgInventory;
import RpgInventory.item.armor.BonusArmor;
import RpgInventory.item.armor.ItemRpgArmor;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/**
 *
 * @author Home
 */
public enum EnumRpgClass {
    
    ARCHER, MAGE, BERSERKER, SHIELDEDARCHER, SHIELDEDMAGE, SHIELDEDBERSERKER,
    WOOD,IRON,GOLD,DIAMOND;
    
    public static EnumRpgClass getPlayerClass(EntityPlayer p){
        EnumRpgClass tmp = null;
        for(ItemStack is: p.inventory.armorInventory){
            if(is == null){
                return null;
            }
            if(is.getItem() instanceof BonusArmor){
                if(is.getItem().equals(mod_RpgInventory.archerhood) || is.getItem().equals(mod_RpgInventory.archerchest)
                        || is.getItem().equals(mod_RpgInventory.archerpants)|| is.getItem().equals(mod_RpgInventory.archerboots)){
                    if(tmp == null){
                        tmp = ARCHER;
                    }
                    if(tmp != ARCHER){
                        return null;
                    }
                }else if(is.getItem().equals(mod_RpgInventory.magehood) || is.getItem().equals(mod_RpgInventory.magegown)
                        || is.getItem().equals(mod_RpgInventory.magepants)|| is.getItem().equals(mod_RpgInventory.mageboots)){
                    if(tmp == null){
                        tmp = MAGE;
                    }
                    if(tmp != MAGE){
                        return null;
                    }
                }else if(is.getItem().equals(mod_RpgInventory.berserkerHood) || is.getItem().equals(mod_RpgInventory.berserkerChest)
                        || is.getItem().equals(mod_RpgInventory.berserkerLegs)|| is.getItem().equals(mod_RpgInventory.berserkerBoots)){
                    if(tmp == null){
                        tmp = BERSERKER;
                    }
                    if(tmp != BERSERKER){
                        return null;
                    }
                }
            }else{
                return null;
            }
        }
        RpgInventory inv = mod_RpgInventory.proxy.getInventory(p.username);
        if(inv != null){
            ItemStack shield = inv.getShield();
            if(shield != null){
                if(shield.getItem().equals(mod_RpgInventory.archersShield) && tmp == ARCHER){
                    tmp = SHIELDEDARCHER;
                }else if(shield.getItem().equals(mod_RpgInventory.talisman) && tmp == MAGE){
                    tmp = SHIELDEDMAGE;
                }else if(shield.getItem().equals(mod_RpgInventory.berserkerShield) && tmp == BERSERKER){
                    tmp = SHIELDEDBERSERKER;
                }else if(shield.getItem().equals(mod_RpgInventory.shieldWood)){
                    tmp = WOOD;
                }else if(shield.getItem().equals(mod_RpgInventory.shieldIron)){
                    tmp = IRON;
                }else if(shield.getItem().equals(mod_RpgInventory.shieldGold)){
                    tmp = GOLD;
                }else if(shield.getItem().equals(mod_RpgInventory.shieldDiamond)){
                    tmp = DIAMOND;
                }
            }
        }
        return tmp;
    } 

}
