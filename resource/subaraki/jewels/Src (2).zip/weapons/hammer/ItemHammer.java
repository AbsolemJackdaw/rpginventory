package RpgInventory.weapons.hammer;

import java.util.Random;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import RpgInventory.mod_RpgInventory;
import RpgInventory.gui.inventory.RpgInventory;

public class ItemHammer extends Item{

	private EnumToolMaterial toolMaterial;
	private int weaponDamage;
	Random rand = new Random();
	int damage;
	public ItemHammer(int par1, EnumToolMaterial mat) {
		super(par1);
		this.toolMaterial = mat;
		this.maxStackSize = 1;
		this.setMaxDamage(mat.getMaxUses());
		this.setCreativeTab(CreativeTabs.tabCombat);
		this.weaponDamage = 4 + mat.getDamageVsEntity();

	}

	public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer player)
	{
		ItemStack var3 = player.inventory.armorItemInSlot(3);
		ItemStack var2 = player.inventory.armorItemInSlot(2);
		ItemStack var1 = player.inventory.armorItemInSlot(1);
		ItemStack var0 = player.inventory.armorItemInSlot(0);
		RpgInventory rpg = mod_RpgInventory.proxy.getInventory(player.username);
		ItemStack shield = rpg.getJewelInSlot(1);
		if (var3 !=null && var2 !=null && var1 != null && var0 !=null)
		{
			Item item  = var3.getItem();
			Item item1 = var2.getItem();
			Item item2 = var1.getItem();
			Item item3 = var0.getItem();

			if(item.equals(mod_RpgInventory.berserkerHood) && item1.equals(mod_RpgInventory.berserkerChest)
					&& item2.equals(mod_RpgInventory.berserkerLegs)&& item3.equals(mod_RpgInventory.berserkerBoots))
			{
				if(shield != null && shield.getItem() == mod_RpgInventory.berserkerShield)
				{
					if(player.getFoodStats().getFoodLevel() < 6 
							||player.getHealth() < 6)
					{
						player.addPotionEffect(new PotionEffect(Potion.damageBoost.id,200,2));
						damage = 10;
					}
				}
				else
				{
					if(player.getFoodStats().getFoodLevel() < 4 
							||player.getHealth() < 4)
					{

						player.addPotionEffect(new PotionEffect(Potion.damageBoost.id,200,1));
						damage = 10;
					}
				}

			}
			par1ItemStack.damageItem(1, player);
		}
		return par1ItemStack;
	}

	public boolean hitEntity(ItemStack par1ItemStack, EntityLiving par2EntityLiving, EntityLiving par3EntityLiving)
	{
		par1ItemStack.damageItem(2, par2EntityLiving);
		EntityPlayer player = (EntityPlayer)par3EntityLiving;

		ItemStack var3 = player.inventory.armorItemInSlot(3);
		ItemStack var2 = player.inventory.armorItemInSlot(2);
		ItemStack var1 = player.inventory.armorItemInSlot(1);
		ItemStack var0 = player.inventory.armorItemInSlot(0);

		if (var3 !=null && var2 !=null && var1 != null && var0 !=null)
		{
			Item item  = var3.getItem();
			Item item1 = var2.getItem();
			Item item2 = var1.getItem();
			Item item3 = var0.getItem();
			RpgInventory rpg = mod_RpgInventory.proxy.getInventory(player.username);
			ItemStack shield = rpg.getJewelInSlot(1);

			if(item.equals(mod_RpgInventory.berserkerHood) && item1.equals(mod_RpgInventory.berserkerChest)
					&& item2.equals(mod_RpgInventory.berserkerLegs)&& item3.equals(mod_RpgInventory.berserkerBoots))
			{
				int var4;
				var4 =5;
				var4 += EnchantmentHelper.getKnockbackModifier(par3EntityLiving, par2EntityLiving);
				if(shield != null && shield.getItem() == mod_RpgInventory.berserkerShield)
				{
					if (var4 > 0)
					{
						par2EntityLiving.addVelocity((double)(-MathHelper.sin(par3EntityLiving.rotationYaw * (float)Math.PI / 180.0F) * (float)var4 * 0.5F), 0.1D, (double)(MathHelper.cos(par3EntityLiving.rotationYaw * (float)Math.PI / 180.0F) * (float)var4 * 0.5F));
						par3EntityLiving.motionX *= 0.6D;
						par3EntityLiving.motionZ *= 0.6D;
						par2EntityLiving.attackEntityFrom(DamageSource.cactus, weaponDamage*3);
					}
				}
				else
				{
					if (var4 > 0)
					{
						par2EntityLiving.addVelocity((double)(-MathHelper.sin(par3EntityLiving.rotationYaw * (float)Math.PI / 180.0F) * (float)var4 * 0.5F), 0.1D, (double)(MathHelper.cos(par3EntityLiving.rotationYaw * (float)Math.PI / 180.0F) * (float)var4 * 0.5F));
						par3EntityLiving.motionX *= 0.1D;
						par3EntityLiving.motionZ *= 0.1D;
						par2EntityLiving.attackEntityFrom(DamageSource.cactus, weaponDamage+4);
					}
				}
			}
		}
		return false;
	}
	public String getTextureFile()
	{
		return "/subaraki/RPGinventoryTM.png";
	}
}
