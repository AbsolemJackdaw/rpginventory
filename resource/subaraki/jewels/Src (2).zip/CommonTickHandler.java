package RpgInventory;

import java.util.EnumSet;
import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import RpgInventory.gui.inventory.RpgInventory;
import RpgInventory.item.armor.ItemRpgArmor;
import RpgInventory.weapons.bow.BowRender;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.TickType;
import cpw.mods.fml.common.network.PacketDispatcher;
import cpw.mods.fml.server.FMLServerHandler;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBow;
import net.minecraft.network.packet.Packet250CustomPayload;
import net.minecraft.world.WorldServer;

public class CommonTickHandler implements ITickHandler {

    private static int countdown = 20;
    public static Map<String, Integer> cooldownMap = new HashMap();

    @Override
    public void tickStart(EnumSet<TickType> type, Object... tickData) {
        for (String usernames : RPGEventHooks.ArcherRepairTick.keySet()) {
            if (RPGEventHooks.ArcherRepairTick.get(usernames) > 0) {
                RPGEventHooks.ArcherRepairTick.put(usernames, RPGEventHooks.ArcherRepairTick.get(usernames) - 1);
            } else {
                for (WorldServer ws : FMLCommonHandler.instance().getMinecraftServerInstance().worldServers) {
                    EntityPlayer player = ws.getPlayerEntityByName(usernames);
                    if (player == null) {
                        continue;
                    }
                    EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(player);
                    if (rpgclass != EnumRpgClass.ARCHER && rpgclass != EnumRpgClass.SHIELDEDARCHER) {
                        RPGEventHooks.ArcherRepairTick.remove(usernames);
                        return;
                    }
                    if (player.getCurrentEquippedItem() != null) {
                        if (player.getCurrentEquippedItem().getItem() instanceof ItemBow || player.getCurrentEquippedItem().getItem().equals(mod_RpgInventory.elfbow)) {
                            if (!player.isUsingItem()) {
                                RPGEventHooks.ArcherRepairTick.put(player.username, 60);

                                if (player.inventory.getCurrentItem().getItemDamage() <= 1) {
                                    player.inventory.getCurrentItem().setItemDamage(0);
                                } else {
                                    player.inventory.getCurrentItem().setItemDamage(player.inventory.getCurrentItem().getItemDamage() - 1);
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
        for (String username : RPGEventHooks.DiamondTick.keySet()) {
            if (RPGEventHooks.DiamondTick.get(username) > 0) {
                RPGEventHooks.DiamondTick.put(username, RPGEventHooks.DiamondTick.get(username) - 1);
            } else {
                for (WorldServer ws : FMLCommonHandler.instance().getMinecraftServerInstance().worldServers) {
                    EntityPlayer player = ws.getPlayerEntityByName(username);
                    if (player == null) {
                        continue;
                    }
                    RpgInventory rpginv = mod_RpgInventory.proxy.getInventory(username);
                    if (rpginv == null) {
                        break;
                    }
                    boolean keepinList = false;
                    int delay = 70;
                    if (rpginv.getNecklace() != null && rpginv.getNecklace().getItem().equals(mod_RpgInventory.neckdia)) {
                        delay -= 10;
                        keepinList = true;
                    }
                    if (rpginv.getGloves() != null && rpginv.getGloves().getItem().equals(mod_RpgInventory.glovesdia)) {
                        delay -= 10;
                        keepinList = true;
                    }
                    if (rpginv.getRing1() != null && rpginv.getRing1().getItem().equals(mod_RpgInventory.ringdia)) {
                        delay -= 10;
                        keepinList = true;
                    }
                    if (rpginv.getRing2() != null && rpginv.getRing2().getItem().equals(mod_RpgInventory.ringdia)) {
                        delay -= 10;
                        keepinList = true;
                    }
                    if (keepinList) {
                        RPGEventHooks.DiamondTick.put(player.username, delay);
                        if (player.getHealth() < player.getMaxHealth()) {
                            player.heal(1);
                        }
                    } else {
                        RPGEventHooks.DiamondTick.remove(player.username);
                    }

                    break;
                }
            }



        }
        for (String username : RPGEventHooks.HealerTick.keySet()) {
            if (RPGEventHooks.HealerTick.get(username) > 0) {
                RPGEventHooks.HealerTick.put(username, RPGEventHooks.HealerTick.get(username) - 1);
            } else {
                for (WorldServer ws : FMLCommonHandler.instance().getMinecraftServerInstance().worldServers) {
                    EntityPlayer player = ws.getPlayerEntityByName(username);
                    if (player == null) {
                        continue;
                    }
                    EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(player);
                    if (rpgclass != EnumRpgClass.MAGE && rpgclass != EnumRpgClass.SHIELDEDMAGE) {
                        RPGEventHooks.HealerTick.remove(username);
                        return;
                    }
                    if (player.getCurrentEquippedItem() != null) {
                        if (player.getCurrentEquippedItem().getItem().equals(mod_RpgInventory.staf)) {
                            if (player.isUsingItem()) {
                                RPGEventHooks.HealerTick.put(player.username, 30);
                                if (player.getHealth() < player.getMaxHealth()) {
                                    player.heal(1);
                                }
                            }
                            break;
                        }
                    }
                }
            }

        }

    }

    @Override
    public void tickEnd(EnumSet<TickType> type, Object... tickData) {
        for (Entry<String, Integer> entry : cooldownMap.entrySet()) {
            if (entry.getValue() > 0) {
                entry.setValue(entry.getValue() - 1);
            }
            if (mod_RpgInventory.developers.contains(entry.getKey())) {
                entry.setValue(0);
            }
        }
        List<EntityPlayer> players = MinecraftServer.getServerConfigurationManager(MinecraftServer.getServer()).playerEntityList;
        for (EntityPlayer player : players) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(bos);
            try {
                RpgInventory rinv = mod_RpgInventory.proxy.getInventory(player.username);
                dos.writeInt(2);
                dos.writeUTF(player.username);
                //Cycle through the itemslots for this player
                for (int i = 0; i <= 5; i++) {
                    try {
                        ItemStack is = rinv.armorSlots[i];
                        if (is != null) {
                            ItemRpgArmor item = (ItemRpgArmor) is.getItem();
                            item.armorEffects(is, player);
                            dos.writeInt(is.itemID);
                        } else {
                            //0 represents no item in the slot.
                            dos.writeInt(0);
                        }
                    } catch (Throwable ex) {
                        dos.writeInt(0);
                    }
                }
                //dos.flush();
                //send this to all players, players recieving updates about themselves will ignore
                //this to prevent anomolies.
                if (countdown == 0) {
                    Packet250CustomPayload packet = new Packet250CustomPayload("RpgInv", bos.toByteArray());
                    PacketDispatcher.sendPacketToAllPlayers(packet);
                }
            } catch (Throwable ex) {
                ex.printStackTrace();
            }
            try {
                bos.close();
                dos.close();
            } catch (IOException ex) {
                Logger.getLogger(CommonTickHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (player.getHealth() <= 0) {
                dropJewels(player);
            } else if (player.isDead) {
                dropJewels(player);

            }
        }

        countdown--;
        if (countdown < 0) {
            countdown = 20;
        }


    }

    public void dropJewels(EntityPlayer player) {
        if (FMLCommonHandler.instance().getEffectiveSide().isServer()) {
            if (player.worldObj.getGameRules().getGameRuleBooleanValue("keepInventory") == false) {
                RpgInventory rpg = mod_RpgInventory.proxy.getInventory(player.username);
                int var1;
                player.inventory.dropAllItems();
                for (var1 = 0; var1 < rpg.armorSlots.length; ++var1) {
                    if (rpg.getStackInSlot(var1) != null) {
                        player.inventory.setInventorySlotContents(player.inventory.getFirstEmptyStack(), rpg.getStackInSlot(var1));
                        rpg.setInventorySlotContents(var1, null);
                    }
                }
                player.inventory.dropAllItems();
                //System.out.println("JEWELS DROPPED!");
            }
        }
    }

    /**
     * called upon player's death. Will drop Jewels in the world
     */
    @Override
    public EnumSet<TickType> ticks() {
        return EnumSet.of(TickType.SERVER);
    }

    @Override
    public String getLabel() {
        return "RpgInventoryServ";
    }
}
