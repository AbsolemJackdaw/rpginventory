package RpgInventory;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumArmorMaterial;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.WeightedRandomChestContent;
import net.minecraftforge.client.IItemRenderer;
import net.minecraftforge.client.MinecraftForgeClient;
import net.minecraftforge.common.ChestGenHooks;
import net.minecraftforge.common.Configuration;
import net.minecraftforge.common.EnumHelper;
import net.minecraftforge.common.MinecraftForge;
import RpgInventory.forge.BlockForge;
import RpgInventory.forge.TEMold;
import RpgInventory.gui.RpgInventoryTab;
import RpgInventory.item.ItemRageFood;
import RpgInventory.item.ItemRpg;
import RpgInventory.item.armor.BonusArmor;
import RpgInventory.item.armor.ItemRpgArmor;
import RpgInventory.weapons.bow.BowRender;
import RpgInventory.weapons.bow.EntityHellArrow;
import RpgInventory.weapons.bow.ItemArcherBow;
import RpgInventory.weapons.claymore.ClaymoreRenderer;
import RpgInventory.weapons.claymore.ItemClaymore;
import RpgInventory.weapons.hammer.HammerRender;
import RpgInventory.weapons.hammer.ItemHammer;
import RpgInventory.weapons.staf.ItemStaf;
import RpgInventory.weapons.staf.StafRender;
import RpgInventory.weapons.wand.ItemMageWand;
import RpgInventory.weapons.wand.SoulSphereRender;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Mod.PreInit;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.NetworkMod.SidedPacketHandler;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;
import cpw.mods.fml.common.registry.TickRegistry;
import cpw.mods.fml.relauncher.Side;

@Mod(modid = "RPGInventoryMod", name = "RPG Inventory Mod", version = "14751")
@NetworkMod(clientSideRequired = true, serverSideRequired = false,
clientPacketHandlerSpec =
@SidedPacketHandler(channels = {"RpgInv"}, packetHandler = RpgPacketHandler.class),
serverPacketHandlerSpec =
@SidedPacketHandler(channels = {"RpgInv"}, packetHandler = RpgPacketHandler.class))
public class mod_RpgInventory {

    EntityPlayer player;
    public static Item neckgold;
    public static Item neckdia;
    public static Item neckem;
    public static Item necklap;
    public static Item glovesbutter;
    public static Item glovesdia;
    public static Item glovesem;
    public static Item gloveslap;
    public static Item ringgold;
    public static Item ringdia;
    public static Item ringem;
    public static Item ringlap;
    public static Item archersShield;
    public static Item berserkerShield;
    public static Item talisman;
    public static Item shieldWood;
    public static Item shieldIron;
    public static Item shieldGold;
    public static Item shieldDiamond;
    public static Item cloak;
    public static Item cloakI;
    public static Item cloakSub;
    public static Item cloakRed;
    public static Item cloakYellow;
    public static Item cloakGreen;
    public static Item cloakBlue;
    public static Item elfbow;			//  goes with Archers.
    public static Item claymore;		// goes with Berserkers
    public static Item hammer;
    public static Item wand;			// goes with Mages
    public static Item staf;
    public static Item rageSeed;
    public static Item magehood;
    public static Item magegown;
    public static Item magepants;
    public static Item mageboots;
    public static Item archerhood;
    public static Item archerchest;
    public static Item archerpants;
    public static Item archerboots;
    public static Item berserkerHood;
    public static Item berserkerChest;
    public static Item berserkerLegs;
    public static Item berserkerBoots;
    public static Item animalskin;
    public static Item tanHide;
    public static Item magecloth;
    public static Item wizardBook;
    public static Item colmold;
    public static Item ringmold;
    public static Item wantmold;
    //public static Block forgeBlock;
    //Die bitches.
    public static List<String> developers = new ArrayList<String>();
    private String[][] recipePatterns;
    private Object[][] recipeItems;
    @SidedProxy(serverSide = "RpgInventory.CommonProxy", clientSide = "RpgInventory.ClientProxy")
    public static CommonProxy proxy;
    public static mod_RpgInventory instance;
    public static boolean render3DClaymore;
    public static boolean render3DHammer;
    public static boolean render3DSoulSphere;
    public static boolean render3DStaff;
    public static boolean render3DBow;
    public static boolean useSpell;
    public static boolean hasRpg;
    private static int uniqueID = 0;
    private int countMin = 0;
    private int countMax = 0;

    public int getUniqueID() {
        return uniqueID++;
    }

    public mod_RpgInventory() {
        instance = this;
    }
    EnumArmorMaterial robes = EnumHelper.addArmorMaterial("magerobes", 20, new int[]{2, 2, 2, 1}, 5);	// use of Magic Tools
    EnumArmorMaterial hides = EnumHelper.addArmorMaterial("hides", 20, new int[]{2, 3, 2, 2}, 5);		// use of Bows
    EnumArmorMaterial armoury = EnumHelper.addArmorMaterial("armoury", 20, new int[]{2, 4, 3, 2}, 5);		// use of RageBreaker and Claymore
    EnumToolMaterial clay = EnumHelper.addToolMaterial("claymore", 0, 1024, 5F, 6, 0);
    EnumToolMaterial stone = EnumHelper.addToolMaterial("RageBreaker", 0, 750, 5F, 4, 0);
    public static CreativeTabs tab;

    @PreInit
    public void preInit(FMLPreInitializationEvent event) {
        Configuration config = new Configuration(event.getSuggestedConfigurationFile());

        config.load();

        render3DClaymore = config.get(config.CATEGORY_GENERAL, "RenderClaymore", true).getBoolean(true);

        render3DHammer = config.get(config.CATEGORY_GENERAL, "RenderHammer", true).getBoolean(true);

        render3DSoulSphere = config.get(config.CATEGORY_GENERAL, "RenderSoulSphere", true).getBoolean(true);

        render3DStaff = config.get(config.CATEGORY_GENERAL, "RenderStaff", true).getBoolean(true);

        render3DBow = config.get(config.CATEGORY_GENERAL, "RenderBow", true).getBoolean(true);

        useSpell = config.get(config.CATEGORY_GENERAL, "DayNight Cycle Spell: useSpell ?", true).getBoolean(true);

        config.save();
    }

    @Init
    public void load(FMLInitializationEvent event) {
        // NOTHING BEFORE THE GOD DAMN TAB !
    	
    	// 5827 - 5840 are used in Rpg ++
    	
        tab = new RpgInventoryTab(CreativeTabs.getNextID(), "RpgTab");
        developers.add("Unjustice");
        developers.add("Artix_all_mighty");
        //forgeBlock = new BlockForge(575, Material.rock).setBlockName("MoldForge").setCreativeTab(tab);
        neckgold = new ItemRpgArmor(5780, 0, -1).setIconIndex(0).setItemName("goldnecklace").setCreativeTab(tab);
        neckdia = new ItemRpgArmor(5781, 0, -1).setIconIndex(0 + 16).setItemName("neckwithdia").setCreativeTab(tab);
        neckem = new ItemRpgArmor(5782, 0, -1).setIconIndex(0 + 32).setItemName("neckwithem").setCreativeTab(tab);
        necklap = new ItemRpgArmor(5783, 0, -1).setIconIndex(0 + 48).setItemName("neckwithlap").setCreativeTab(tab);

        ringgold = new ItemRpgArmor(5784, 4, -1).setIconIndex(1).setItemName("goldring").setCreativeTab(tab);
        ringdia = new ItemRpgArmor(5785, 4, -1).setIconIndex(1 + 16).setItemName("ringwithdia").setCreativeTab(tab);
        ringem = new ItemRpgArmor(5786, 4, -1).setIconIndex(1 + 32).setItemName("ringwithem").setCreativeTab(tab);
        ringlap = new ItemRpgArmor(5787, 4, -1).setIconIndex(1 + 48).setItemName("ringwithlapis").setCreativeTab(tab);

        glovesbutter = new ItemRpgArmor(5788, 3, -1).setIconIndex(2).setItemName("goldrrgloves").setCreativeTab(tab);
        glovesdia = new ItemRpgArmor(5789, 3, -1).setIconIndex(2 + 16).setItemName("glovesdia").setCreativeTab(tab);
        glovesem = new ItemRpgArmor(5790, 3, -1).setIconIndex(2 + 32).setItemName("glovesem").setCreativeTab(tab);
        gloveslap = new ItemRpgArmor(5791, 3, -1).setIconIndex(2 + 48).setItemName("gloveslap").setCreativeTab(tab);

        archersShield = new ItemRpgArmor(5792, 1, 200).setIconIndex(3).setItemName("woodshield").setCreativeTab(tab);
        berserkerShield = new ItemRpgArmor(5793, 1, 350).setIconIndex(4).setItemName("ironshield").setCreativeTab(tab);
        talisman = new ItemRpgArmor(5794, 1, 200).setIconIndex(5).setItemName("talisman").setCreativeTab(tab);

        cloak = new ItemRpgArmor(5795, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloak").setCreativeTab(tab);
        cloakI = new ItemRpgArmor(5796, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("InvisibilityCloak").setCreativeTab(tab);

        magehood = new BonusArmor(5797, robes, 4, 0).setItemName("magehoody").setIconIndex(15).setCreativeTab(tab);
        magegown = new BonusArmor(5798, robes, 4, 1).setItemName("magegowny").setIconIndex(31).setCreativeTab(tab);
        magepants = new BonusArmor(5799, robes, 4, 2).setItemName("magepants").setIconIndex(47).setCreativeTab(tab);
        mageboots = new BonusArmor(5800, robes, 4, 3).setItemName("mageshoes").setIconIndex(63).setCreativeTab(tab);

        archerhood = new BonusArmor(5801, hides, 4, 0).setItemName("archerhoody").setIconIndex(14).setCreativeTab(tab);
        archerchest = new BonusArmor(5802, hides, 4, 1).setItemName("archerdhide").setIconIndex(30).setCreativeTab(tab);
        archerpants = new BonusArmor(5803, hides, 4, 2).setItemName("archerpants").setIconIndex(46).setCreativeTab(tab);
        archerboots = new BonusArmor(5804, hides, 4, 3).setItemName("archerboots").setIconIndex(62).setCreativeTab(tab);

        berserkerHood = new BonusArmor(5805, armoury, 4, 0).setItemName("rambo1").setIconIndex(13).setCreativeTab(tab);
        berserkerChest = new BonusArmor(5806, armoury, 4, 1).setItemName("rambo2").setIconIndex(29).setCreativeTab(tab);
        berserkerLegs = new BonusArmor(5807, armoury, 4, 2).setItemName("rambo3").setIconIndex(45).setCreativeTab(tab);
        berserkerBoots = new BonusArmor(5808, armoury, 4, 3).setItemName("rambo4").setIconIndex(61).setCreativeTab(tab);

        claymore = new ItemClaymore(5809, clay).setFull3D().setMaxDamage(1024).setItemName("Daggerkiller").setIconIndex(20).setCreativeTab(tab);
        wand = new ItemMageWand(5810).setFull3D().setMaxDamage(400).setItemName("MagesWand").setIconIndex(21).setCreativeTab(tab);
        elfbow = new ItemArcherBow(5811).setFull3D().setMaxDamage(350).setItemName("ArcherBow").setIconIndex(22).setCreativeTab(tab);

        animalskin = new ItemRpg(5812).setItemName("animal skin").setIconIndex(103).setCreativeTab(tab);
        tanHide = new ItemRpg(5813).setItemName("tanned hide").setIconIndex(103).setCreativeTab(tab);
        magecloth = new ItemRpg(5814).setItemName("mage cloth").setIconIndex(103).setCreativeTab(tab);

        wizardBook = new ItemRpg(5815).setItemName("wizardbook").setIconCoord(11, 11).setCreativeTab(tab);

        hammer = new ItemHammer(5816, stone).setItemName("BerserkerHammer").setMaxDamage(750).setIconIndex(26).setCreativeTab(tab);
        staf = new ItemStaf(5817).setItemName("MageStaff").setMaxStackSize(1).setMaxDamage(1500).setIconIndex(37).setCreativeTab(tab);

        rageSeed = new ItemRageFood(5818, 0, 0f, false).setAlwaysEdible().setIconCoord(9, 0).setItemName("RageSeed").setMaxStackSize(8).setCreativeTab(tab);

        cloakRed = new ItemRpgArmor(5819, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloakred").setCreativeTab(tab);
        cloakYellow = new ItemRpgArmor(5820, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloakyellow").setCreativeTab(tab);
        cloakGreen = new ItemRpgArmor(5821, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloakgreen").setCreativeTab(tab);
        cloakBlue = new ItemRpgArmor(5822, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloaksaint").setCreativeTab(tab);
        cloakSub = new ItemRpgArmor(5823, 2, -1).setFull3D().setIconIndex(3 + 16).setItemName("cloakSub").setCreativeTab(tab);

        colmold = new ItemMold(5824).setIconIndex(64).setItemName("colmold").setCreativeTab(tab);
        ringmold = new ItemMold(5825).setIconIndex(65).setItemName("ringmold").setCreativeTab(tab);
        wantmold = new ItemMold(5826).setIconIndex(66).setItemName("wantmold").setCreativeTab(tab);

        shieldWood = new ItemRpgArmor(5841,1,50).setIconIndex(67).setItemName("vanillaWood").setCreativeTab(tab);
        shieldIron = new ItemRpgArmor(5842,1,125).setIconIndex(68).setItemName("vanillaIron").setCreativeTab(tab);
        shieldGold = new ItemRpgArmor(5843,1,250).setIconIndex(69).setItemName("vanillaGold").setCreativeTab(tab);
        shieldDiamond = new ItemRpgArmor(5844,1,500).setIconIndex(70).setItemName("vanillaDiamond").setCreativeTab(tab);

        proxy.registerRenderInformation();

        addChestLoot(new ItemStack(mod_RpgInventory.colmold), 1, 1, 40);
        addChestLoot(new ItemStack(mod_RpgInventory.ringmold), 1, 1, 30);
        addChestLoot(new ItemStack(mod_RpgInventory.wantmold), 1, 1, 40);

        GameRegistry.registerTileEntity(TEMold.class, "temold");

        //LanguageRegistry.addName(forgeBlock, "Mold Forge");
        //GameRegistry.registerBlock(forgeBlock, "MoldForge");

        LanguageRegistry.addName(cloakRed, "Red Cape");
        LanguageRegistry.addName(cloakYellow, "Yellow Cape");
        LanguageRegistry.addName(cloakGreen, "Green Cape");
        LanguageRegistry.addName(cloakBlue, "Blue Cape");
        LanguageRegistry.addName(cloakSub, "Subaraki's Cape");

        LanguageRegistry.addName(neckgold, "Gold Necklace");
        LanguageRegistry.addName(neckdia, "Health Necklace");
        LanguageRegistry.addName(neckem, " Buffed Necklace");
        LanguageRegistry.addName(necklap, " Strength Necklace");

        LanguageRegistry.addName(glovesbutter, "Gold Gloves");
        LanguageRegistry.addName(glovesdia, "Health Gloves");
        LanguageRegistry.addName(glovesem, "Buffed Gloves");
        LanguageRegistry.addName(gloveslap, "Strength Gloves");

        LanguageRegistry.addName(ringgold, "Golden Ring");
        LanguageRegistry.addName(ringdia, "Health Ring");
        LanguageRegistry.addName(ringem, "Buffed Ring");
        LanguageRegistry.addName(ringlap, "Strength Ring");

        LanguageRegistry.addName(archersShield, "Wooden Shield");
        LanguageRegistry.addName(berserkerShield, "Berserker's Iron Thorn");
        LanguageRegistry.addName(talisman, "Wizard's Talisman");
        LanguageRegistry.addName(shieldWood, "Wooden Shield");
        LanguageRegistry.addName(shieldIron, "Iron Shield");
        LanguageRegistry.addName(shieldGold, "Golden Shield");
        LanguageRegistry.addName(shieldDiamond, "Diamond Shield");

        LanguageRegistry.addName(cloak, "Cloak");
        LanguageRegistry.addName(cloakI, "Invisibility Cloak");

        LanguageRegistry.addName(this.magehood, "Mage Hood");
        LanguageRegistry.addName(this.magegown, "Mage Gown");
        LanguageRegistry.addName(this.magepants, "Mage Under Gown");
        LanguageRegistry.addName(this.mageboots, "Mage Shoes");

        LanguageRegistry.addName(this.archerhood, "Archer Hood");
        LanguageRegistry.addName(this.archerchest, "Archer Chest");
        LanguageRegistry.addName(this.archerpants, "Archer Leggings");
        LanguageRegistry.addName(this.archerboots, "Archer Boots");

        LanguageRegistry.addName(this.berserkerHood, "Berserker's Head Protection");
        LanguageRegistry.addName(this.berserkerChest, "Berserker's Body Protection");
        LanguageRegistry.addName(this.berserkerLegs, "Berserker's Leg Protection");
        LanguageRegistry.addName(this.berserkerBoots, "Berserker's Feet Protection");

        LanguageRegistry.addName(wand, "Soul Sphere");
        LanguageRegistry.addName(claymore, "Berserker's Claymore");
        LanguageRegistry.addName(elfbow, "Archer's Bow of Birch");

        LanguageRegistry.addName(animalskin, "Animal Skin");
        LanguageRegistry.addName(tanHide, "Tanned Hide");
        LanguageRegistry.addName(magecloth, "Mage Cloth");

        LanguageRegistry.addName(wizardBook, "Wizard's Knowledge, Volume I");
        LanguageRegistry.addName(hammer, "Berserker's Rage Breaker");
        LanguageRegistry.addName(staf, "Lunar Staff");
        LanguageRegistry.addName(rageSeed, "Rage Seeds");

        LanguageRegistry.addName(colmold, "Mold");
        LanguageRegistry.addName(ringmold, "Mold");
        LanguageRegistry.addName(wantmold, "Mold");

        MinecraftForge.addGrassSeed(new ItemStack(rageSeed, 1), 1);

        //SKINS
        GameRegistry.addRecipe(new ItemStack(animalskin, 1), new Object[]{"WWW", "WLW", "WWW", 'W', new ItemStack(Block.cloth, 1, 12), 'L', Item.leather});
        GameRegistry.addShapelessRecipe(new ItemStack(tanHide, 1), new Object[]{Item.leather, Item.silk, Item.silk, Item.silk, Item.silk});
        GameRegistry.addRecipe(new ItemStack(magecloth, 1), new Object[]{"WWW", "WLW", "WWW", 'W', new ItemStack(Item.dyePowder, 1, 4), 'L', Item.leather});
        //WEAPONRY
        GameRegistry.addRecipe(new ItemStack(elfbow, 1), new Object[]{"EPP", "P S", "PS ", 'E', Item.emerald, 'S', Item.silk, 'P', new ItemStack(Block.wood, 1, 2)});
        GameRegistry.addRecipe(new ItemStack(wand, 1), new Object[]{"GGG", "GLG", "GGG", 'L', Block.blockLapis, 'G', Item.ingotGold});
        GameRegistry.addRecipe(new ItemStack(staf, 1), new Object[]{" ML", " SM", "S  ", 'M', Item.speckledMelon, 'S', Item.stick, 'L', new ItemStack(Item.dyePowder, 1, 4)});
        GameRegistry.addRecipe(new ItemStack(claymore, 1), new Object[]{" S ", " S ", "LIL", 'I', Item.ingotIron, 'S', Block.stone, 'L', Item.leather});
        GameRegistry.addRecipe(new ItemStack(hammer, 1), new Object[]{"SSS", "LI ", "LI ", 'I', Item.ingotIron, 'S', Block.blockSteel, 'L', Item.leather});

        //SHIELDS
        GameRegistry.addRecipe(new ItemStack(archersShield, 1), new Object[]{"WWW", "WBW", " W ", 'W', Item.ingotIron, 'B', Block.wood});
        GameRegistry.addRecipe(new ItemStack(berserkerShield, 1), new Object[]{"WWW", "WBW", " W ", 'W', Item.ingotIron, 'B', Block.blockSteel});
        GameRegistry.addRecipe(new ItemStack(talisman, 1), new Object[]{"WWW", "WBW", " W ", 'W', new ItemStack(Item.dyePowder, 1, 4), 'B', Block.blockLapis});
        //		//NECKLACE
        //		GameRegistry.addRecipe(new ItemStack(neckgold, 1), new Object[]{" SS", "  S", "I  ", 'S', Item.silk, 'I', Item.ingotGold});
        //		GameRegistry.addRecipe(new ItemStack(neckdia, 1), new Object[]{"e", "d", 'd', neckgold, 'e', Item.diamond});
        //		GameRegistry.addRecipe(new ItemStack(neckem, 1), new Object[]{"e", "d", 'd', neckgold, 'e', Item.emerald});
        //		GameRegistry.addRecipe(new ItemStack(necklap, 1), new Object[]{"e", "d", 'd', neckgold, 'e', new ItemStack(Item.dyePowder, 1, 4)});
        //		//RINGS
        //		GameRegistry.addRecipe(new ItemStack(ringgold, 1), new Object[]{"II ", "I I", "III", 'I', Item.ingotGold});
        //		GameRegistry.addRecipe(new ItemStack(ringdia, 1), new Object[]{"e", "d", 'd', ringgold, 'e', Item.diamond});
        //		GameRegistry.addRecipe(new ItemStack(ringem, 1), new Object[]{"e", "d", 'd', ringgold, 'e', Item.emerald});
        //		GameRegistry.addRecipe(new ItemStack(ringlap, 1), new Object[]{"e", "d", 'd', ringgold, 'e', new ItemStack(Item.dyePowder, 1, 4)});
        //		//GLOVES
        //		GameRegistry.addRecipe(new ItemStack(glovesbutter, 1), new Object[]{" II", "LII", "IL ", 'I', Item.ingotGold, 'L', Item.leather});
        //		GameRegistry.addRecipe(new ItemStack(glovesdia, 1), new Object[]{"e", "d", 'd', glovesbutter, 'e', Item.diamond});
        //		GameRegistry.addRecipe(new ItemStack(glovesem, 1), new Object[]{"e", "d", 'd', glovesbutter, 'e', Item.emerald});
        //		GameRegistry.addRecipe(new ItemStack(gloveslap, 1), new Object[]{"e", "d", 'd', glovesbutter, 'e', new ItemStack(Item.dyePowder, 1, 4)});
        //CLOAK
        GameRegistry.addRecipe(new ItemStack(cloak, 1), new Object[]{"SS", "II", "II", 'I', Block.cloth, 'S', Item.silk});
        GameRegistry.addRecipe(new ItemStack(cloakI, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.potion, 1, 8206)});
        GameRegistry.addRecipe(new ItemStack(cloakI, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.potion, 1, 8270)});

        GameRegistry.addRecipe(new ItemStack(cloakRed, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.dyePowder, 1, 1)});
        GameRegistry.addRecipe(new ItemStack(cloakYellow, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.dyePowder, 1, 11)});
        GameRegistry.addRecipe(new ItemStack(cloakGreen, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.dyePowder, 1, 2)});
        GameRegistry.addRecipe(new ItemStack(cloakBlue, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.dyePowder, 1, 12)});
        GameRegistry.addRecipe(new ItemStack(cloakSub, 1), new Object[]{"PPP", "PCP", "PPP", 'C', cloak, 'P', new ItemStack(Item.dyePowder, 1, 0)});

        //GameRegistry.addRecipe(new ItemStack(forgeBlock, 1), new Object[]{"BBB", "BOB", "BBB", 'B', Block.brick, 'O',Block.obsidian});

        //MageBook
        GameRegistry.addShapelessRecipe(new ItemStack(wizardBook, 1), new Object[]{magecloth, Item.paper, Item.paper, Item.paper});

        //ARMOR
        recipePatterns = new String[][]{{"XXX", "X X"}, {"X X", "XXX", "XXX"}, {"XXX", "X X", "X X"}, {"X X", "X X"}};
        recipeItems = new Object[][]{{animalskin, tanHide, magecloth}, {berserkerHood, archerhood, magehood},
            {berserkerChest, archerchest, magegown}, {berserkerLegs, archerpants, magepants},
            {berserkerBoots, archerboots, mageboots}};

        for (int var2 = 0; var2 < this.recipeItems[0].length; ++var2) {
            Object var3 = this.recipeItems[0][var2];

            for (int var4 = 0; var4 < this.recipeItems.length - 1; ++var4) {
                Item var5 = (Item) this.recipeItems[var4 + 1][var2];
                GameRegistry.addRecipe(new ItemStack(var5), new Object[]{this.recipePatterns[var4], 'X', var3});
            }
        }

        if (render3DClaymore == true) {
            MinecraftForgeClient.registerItemRenderer(mod_RpgInventory.claymore.itemID, (IItemRenderer) new ClaymoreRenderer());
        }
        if (render3DHammer == true) {
            MinecraftForgeClient.registerItemRenderer(mod_RpgInventory.hammer.itemID, (IItemRenderer) new HammerRender());
        }
        if (render3DSoulSphere == true) {
            MinecraftForgeClient.registerItemRenderer(mod_RpgInventory.wand.itemID, (IItemRenderer) new SoulSphereRender());
        }
        if (render3DStaff == true) {
            MinecraftForgeClient.registerItemRenderer(mod_RpgInventory.staf.itemID, (IItemRenderer) new StafRender());
        }
        if (render3DBow == true) {
            MinecraftForgeClient.registerItemRenderer(mod_RpgInventory.elfbow.itemID, (IItemRenderer) new BowRender());
        }


        try {
            Class.forName("RpgPlusPlus.mod_RpgPlus");
            System.out.println("Rpg++ is installed. Renderers can be Used");
            hasRpg = true;
        } catch (Throwable e) {
            System.out.println("Rpg++ has not been detected. Renderers for Rpg++ Ecxluded");
            hasRpg = false;
        }

        NetworkRegistry.instance().registerGuiHandler(this, new GuiHandler());
        GameRegistry.registerPlayerTracker(new PlayerTracker());
        TickRegistry.registerTickHandler(new CommonTickHandler(), Side.SERVER);
        MinecraftForge.EVENT_BUS.register(new RPGEventHooks());
        EntityRegistry.registerModEntity(EntityHellArrow.class, "hellArrow", getUniqueID(), this, 250, 1, true);



    }

    public static class ITEMTYPE {

        public static final int NECKLACE = 0;
        public static final int SHIELD = 1;
        public static final int CLOAK = 2;
        public static final int GLOVES = 3;
        public static final int RING = 4;
    }

    @Mod.PostInit
    public void postInit(FMLPostInitializationEvent evt) {
        this.proxy.registerLate();
    }

    public void addChestLoot(ItemStack is, int min, int max, int rarity) {
        System.out.println("Added Loot to chests");
        WeightedRandomChestContent chestGen = new WeightedRandomChestContent(is.copy(), min, max, rarity);

        ChestGenHooks.getInfo("dungeonChest").addItem(chestGen);
        ChestGenHooks.getInfo("villageBlacksmith").addItem(chestGen);
        ChestGenHooks.getInfo("pyramidJungleChest").addItem(chestGen);
        ChestGenHooks.getInfo("pyramidDesertyChest").addItem(chestGen);
        ChestGenHooks.getInfo("mineshaftCorridor").addItem(chestGen);

    }
}
