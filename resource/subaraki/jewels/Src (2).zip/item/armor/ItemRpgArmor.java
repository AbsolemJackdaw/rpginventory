package RpgInventory.item.armor;


import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import RpgInventory.mod_RpgInventory;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import java.util.List;
import net.minecraft.util.StatCollector;

public class ItemRpgArmor extends Item {

    /**
     * Holds the 'base' maxDamage that each armorType have.
     */
    private final int[] maxDamageArray = new int[]{30, 20, 50, 20, 30, 30};
    /**
     * Stores the armor type: 0 is necklace, 2 is cloak, 1 is shield, 3 is
     * gloves, 4 are rings
     */
    public int armorType;
    /**
     * Used on RenderPlayer to select the correspondent armor to be rendered on
     * the player: 0 is cloth, 1 is chain, 2 is iron, 3 is diamond and 4 is
     * gold.
     */
    public int renderJewelIndex;

    public ItemRpgArmor(int par1, int par4, int maxDamage) {
        super(par1);
        this.armorType = par4;
        this.maxStackSize = 1;
        this.setCreativeTab(CreativeTabs.tabCombat);
        this.setMaxDamage(maxDamage);
    }

    @SideOnly(Side.CLIENT)
    public boolean hasEffect(ItemStack par1ItemStack) {
        if (par1ItemStack.itemID == mod_RpgInventory.cloakI.itemID) {
            return true;
        }
        return false;
    }

    @SideOnly(Side.CLIENT)
    public int getColorFromItemStack(ItemStack par1ItemStack, int par2) {
        if (par1ItemStack.itemID == mod_RpgInventory.cloak.itemID) {
            return 16777215;
        }
        if (par1ItemStack.itemID == mod_RpgInventory.cloakRed.itemID) {
            return 0xd2120e;
        }
        if (par1ItemStack.itemID == mod_RpgInventory.cloakGreen.itemID) {
            return 0x0fb15d;
        }
        if (par1ItemStack.itemID == mod_RpgInventory.cloakYellow.itemID) {
            return 0xf7cd09;
        }
        if (par1ItemStack.itemID == mod_RpgInventory.cloakSub.itemID) {
            return 0x440001;
        }
        if (par1ItemStack.itemID == mod_RpgInventory.cloakBlue.itemID) {
            return 0x291ef6;
        }

        return 16777215;
    }

    public void armorEffects(ItemStack is, EntityPlayer player) {

    }

    /**
     * gets the desired effect for jewelry of a certain kind. 0-3 speed boost
     * 4-7 healing, 8-11 damage and weapon healing, 12-15 emerald effects, 16-19
     * shield n cloak
     */
    public void effectSwitch(int id, EntityPlayer player, ItemStack is) {
    }

    /**
     * an effect that simulates drinking from a milk bucket, but only for debuffs.
     */
    public void getMilkEffect(ItemStack itemstack, int time, EntityPlayer player) {
        
    }

    public void healWeapon(EntityPlayer player, int chances) {

    }

    /**
     * Returns the 'max damage' factor array for the armor, each piece of armor
     * have a durability factor (that gets multiplied by armor material factor)
     */
    int[] getMaxDamageArray() {
        return maxDamageArray;
    }

    public String getTextureFile() {
        return "/subaraki/RPGinventoryTM.png";
    }
    
    /**
     * allows items to add custom lines of information to the mouseover description
     */
    public void addInformation(ItemStack stack, EntityPlayer p1, List list, boolean yesno)
    {
    	if(stack.itemID  == mod_RpgInventory.ringem.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Right: Double Block Break Speed; Left: Dispell Debuffs every 20s;"));
    	}
    	
    	if(stack.itemID  == mod_RpgInventory.neckem.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Water Breating"));
    	}
    	
    	if(stack.itemID  == mod_RpgInventory.glovesem.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Resistance"));
    	}
    	
    	if(stack.itemID  == mod_RpgInventory.ringdia.itemID	|| stack.itemID  == mod_RpgInventory.glovesdia.itemID
    			|| stack.itemID  == mod_RpgInventory.neckdia.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Healing"));
    	}
    	
    	if(stack.itemID  == mod_RpgInventory.ringgold.itemID	|| stack.itemID  == mod_RpgInventory.glovesbutter.itemID
    			|| stack.itemID  == mod_RpgInventory.neckgold.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Jump/Speed"));
    	}
    	
    	if(stack.itemID  == mod_RpgInventory.ringlap.itemID	|| stack.itemID  == mod_RpgInventory.gloveslap.itemID
    			|| stack.itemID  == mod_RpgInventory.necklap.itemID)
    	{
    			 list.add(StatCollector.translateToLocal("Strenght/Passive Weapon Healing"));
    	}
    }
}
