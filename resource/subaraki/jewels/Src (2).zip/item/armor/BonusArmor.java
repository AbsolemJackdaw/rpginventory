package RpgInventory.item.armor;

import net.minecraft.item.EnumArmorMaterial;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.IArmorTextureProvider;
import RpgInventory.mod_RpgInventory;
import RpgPlusPlus.mod_RpgPlus;

public class BonusArmor extends ItemArmor implements IArmorTextureProvider
{

	 public final int renderIndex;
	 
	public BonusArmor(int par1, EnumArmorMaterial par2EnumArmorMaterial,
			int par3, int par4) {
		super(par1, par2EnumArmorMaterial, par3, par4);
        this.renderIndex = par3;

	}
	
	
	 public String getTextureFile()
	    {
	            return "/subaraki/RPGinventoryTM.png";
	    }
	@Override
	public String getArmorTextureFile(ItemStack itemstack) {
		if(itemstack.itemID == mod_RpgInventory.magehood.itemID || itemstack.itemID == mod_RpgInventory.magegown.itemID || itemstack.itemID == mod_RpgInventory.mageboots.itemID)
        {
                return "/armor/mage_1.png";
        }
        if(itemstack.itemID == mod_RpgInventory.magepants.itemID )
        {
                return "/armor/mage_2.png";
        }
        
        if( itemstack.itemID == mod_RpgInventory.archerboots.itemID || itemstack.itemID == mod_RpgInventory.archerchest.itemID || itemstack.itemID == mod_RpgInventory.archerhood.itemID)
        {
                return "/armor/arch_1.png";
        }
        if( itemstack.itemID == mod_RpgInventory.archerpants.itemID)
        {
                return "/armor/arch_2.png";
        }
        if( itemstack.itemID == mod_RpgInventory.berserkerHood.itemID || itemstack.itemID == mod_RpgInventory.berserkerChest.itemID || itemstack.itemID == mod_RpgInventory.berserkerBoots.itemID)
        {
                return "/armor/berserk_1.png";
        }
        if( itemstack.itemID == mod_RpgInventory.berserkerLegs.itemID)
        {
                return "/armor/berserk_2.png";
        }
        // RPG++
        if( itemstack.itemID == mod_RpgPlus.necroHood.itemID || itemstack.itemID == mod_RpgPlus.necroChestplate.itemID || itemstack.itemID == mod_RpgPlus.necroBoots.itemID)
        {
                return "/armor/necro_1.png";
        }
        if( itemstack.itemID == mod_RpgPlus.necroLeggings.itemID)
        {
                return "/armor/necro_2.png";
        }
        
        if( itemstack.itemID == mod_RpgPlus.palaHelm.itemID || itemstack.itemID == mod_RpgPlus.palaChest.itemID || itemstack.itemID == mod_RpgPlus.palaBoots.itemID)
        {
                return "/armor/pal_1.png";
        }
        if( itemstack.itemID == mod_RpgPlus.palaLeggings.itemID)
        {
                return "/armor/pal_2.png";
        }
        return "/armor/ac_1.png";
	}	   
}
