/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RpgInventory;

import RpgInventory.gui.inventory.RpgInventory;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MathHelper;
import net.minecraftforge.event.ForgeSubscribe;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

/**
 *
 * @author Home
 */
public class RPGEventHooks {

	public static Map<String, Integer> ArcherRepairTick = new ConcurrentHashMap();
	public static Map<String, Integer> HealerTick = new ConcurrentHashMap();
	public static Map<String, Integer> DiamondTick = new ConcurrentHashMap();

	@ForgeSubscribe
	public void BreakSpeed(PlayerEvent.BreakSpeed evt) {
		if (evt.entityPlayer != null) {
			RpgInventory rpginv = mod_RpgInventory.proxy.getInventory(evt.entityPlayer.username);
			ItemStack ringa = rpginv.getRing1();
			if (ringa != null && ringa.getItem().equals(mod_RpgInventory.ringem)) {
				evt.newSpeed = evt.originalSpeed * 2;
			}
		}
	}

	@ForgeSubscribe
	public void LivingEvent(EntityEvent evt) {
		EntityPlayer p = null;

		if (evt.entity instanceof EntityPlayer) {
			p = (EntityPlayer) evt.entity;
		}
		if (p != null) {
			EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(p);
			if (rpgclass == EnumRpgClass.ARCHER || rpgclass == EnumRpgClass.SHIELDEDARCHER) {
				if (p.inventory.getCurrentItem() != null && p.inventory.getCurrentItem().getItem() != null) {
					if (p.inventory.getCurrentItem().getItem().equals(mod_RpgInventory.elfbow) || p.inventory.getCurrentItem().getItem() instanceof ItemBow) {
						if (!ArcherRepairTick.containsKey(p.username)) {
							ArcherRepairTick.put(p.username, 0);
						}
					}
				}
			} else {
				if (ArcherRepairTick.containsKey(p.username)) {
					ArcherRepairTick.remove(p.username);
				}
			}
		}
	}

	@ForgeSubscribe
	public void DeathEvent(LivingDeathEvent evt) {
		if (evt.entityLiving instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) evt.entityLiving;
			EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(player);
			if (rpgclass == EnumRpgClass.BERSERKER || rpgclass == EnumRpgClass.SHIELDEDBERSERKER) {
				player.worldObj.createExplosion((Entity) player, player.posX, player.posY, player.posZ, 20, false);
			}
		}

	}

	@ForgeSubscribe
	public void PlayerUpdate(PlayerEvent.LivingUpdateEvent evt) {
		if (evt.entityLiving instanceof EntityPlayer) {
			EntityPlayer p = (EntityPlayer) evt.entityLiving;
			if (p != null) {
				RpgInventory rpginv = mod_RpgInventory.proxy.getInventory(p.username);
				ItemStack col = rpginv.getNecklace();
				ItemStack ringa = rpginv.getRing1();
				ItemStack ringb = rpginv.getRing2();
				ItemStack want = rpginv.getGloves();
				if ((col != null && col.itemID == mod_RpgInventory.neckdia.itemID)
						|| (ringa != null && ringa.itemID == mod_RpgInventory.ringdia.itemID)
						|| (ringb != null && ringb.itemID == mod_RpgInventory.ringdia.itemID)
						|| (ringb != null && want.itemID == mod_RpgInventory.glovesdia.itemID)) {
					if (!DiamondTick.containsKey(p.username)) {
						DiamondTick.put(p.username, 0);
					}
				}
				if (col != null && col.getItem().equals(mod_RpgInventory.neckem)
						|| ringb != null && ringb.getItem().equals(mod_RpgInventory.ringem)) {
					p.curePotionEffects(new ItemStack(Item.bucketMilk));
				}

				float speedboost = 0.1F;
				if (col != null && col.itemID == mod_RpgInventory.neckgold.itemID) {
					speedboost += 0.035F;
				}
				if (ringa != null && ringa.getItem() == mod_RpgInventory.ringgold) {
					speedboost += 0.035F;
				}
				if (ringb != null && ringb.getItem() == mod_RpgInventory.ringgold) {
					speedboost += 0.035F;
				}
				if (want != null && want.getItem() == mod_RpgInventory.glovesbutter) {
					speedboost += 0.035F;
				}

				p.landMovementFactor = speedboost;
				EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(p);
				if (rpgclass == EnumRpgClass.MAGE || rpgclass == EnumRpgClass.SHIELDEDMAGE) {
					if (rpgclass == EnumRpgClass.SHIELDEDMAGE) {
						if (p.getCurrentEquippedItem() != null) {
							if (p.getCurrentEquippedItem().getItem().equals(mod_RpgInventory.staf)) {
								if (!HealerTick.containsKey(p.username)) {
									HealerTick.put(p.username, 0);
								}
							}
						}
					}
					p.fallDistance = 0;
					evt.entityLiving.fireResistance = 200;
				} else {
					evt.entityLiving.fireResistance = 0;
				}
				if (rpgclass == EnumRpgClass.ARCHER || rpgclass == EnumRpgClass.SHIELDEDARCHER) {
					p.jumpMovementFactor = 0.09F;
				} else {
					p.jumpMovementFactor = 0.02F;
				}
				ItemStack cloak = mod_RpgInventory.proxy.getInventory(p.username).getCloak();
				if (cloak != null) {
					if (cloak.itemID == mod_RpgInventory.cloakI.itemID) {
						p.addPotionEffect(new PotionEffect(Potion.invisibility.id, 20, 1));
					}
				}
			}
		}
	}

	@ForgeSubscribe
	public void PlayerJump(PlayerEvent.LivingJumpEvent evt) {
		if (evt.entityLiving instanceof EntityPlayer) {
			EntityPlayer p = (EntityPlayer) evt.entityLiving;
			EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(p);
			if (rpgclass == EnumRpgClass.ARCHER || rpgclass == EnumRpgClass.SHIELDEDARCHER) {
				p.jumpMovementFactor = 0.09F;
			} else {
				p.jumpMovementFactor = 0.02F;
			}
		}
	}

	@ForgeSubscribe
	public void PlayerDamage(LivingHurtEvent evt) {

		if (evt.entityLiving != null && evt.entityLiving instanceof EntityPlayer)
		{
			float damageReduction = 0.0F;
			EntityPlayer player = (EntityPlayer) evt.entityLiving;
			EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(player);
			if (rpgclass == EnumRpgClass.WOOD || rpgclass == EnumRpgClass.IRON
					|| rpgclass == EnumRpgClass.GOLD || rpgclass == EnumRpgClass.DIAMOND)
			{
				RpgInventory rpginv = mod_RpgInventory.proxy.getInventory(((EntityPlayer) player).username);
				ItemStack shield = rpginv.getShield();
				if (shield != null) 
				{
					if(rpgclass == EnumRpgClass.WOOD )	
					{
						damageReduction = 0.15f;
					}
					if(rpgclass == EnumRpgClass.IRON )	
					{
						damageReduction = 0.20f;
					}
					if(rpgclass == EnumRpgClass.GOLD )	
					{
						damageReduction = 0.25f;
					}
					if(rpgclass == EnumRpgClass.DIAMOND )	
					{
						damageReduction = 0.30f;
					}
					evt.ammount -= MathHelper.floor_float(((float) evt.ammount) * damageReduction);
					damageItem(shield, rpginv, player, 1, 1);
				}
			}
		}

		Entity damager = evt.source.getSourceOfDamage();
		if (damager != null) {
			if (damager instanceof EntityPlayer) {
				float damagebonus = 0.0F;
				RpgInventory rpginv = mod_RpgInventory.proxy.getInventory(((EntityPlayer) damager).username);
				ItemStack neck = rpginv.getNecklace();
				ItemStack ringa = rpginv.getRing1();
				ItemStack ringb = rpginv.getRing2();
				ItemStack gloves = rpginv.getGloves();
				if (neck != null && neck.getItem().equals(mod_RpgInventory.necklap)) {
					damagebonus += 0.1F;
				}
				if (ringa != null && ringa.getItem().equals(mod_RpgInventory.ringlap)) {
					damagebonus += 0.1F;
				}
				if (ringb != null && ringb.getItem().equals(mod_RpgInventory.ringlap)) {
					damagebonus += 0.1F;
				}
				if (gloves != null && gloves.getItem().equals(mod_RpgInventory.gloveslap)) {
					damagebonus += 0.1F;
				}
				evt.ammount += MathHelper.floor_float(damagebonus * ((float) evt.ammount));
			}
			if (damager instanceof EntityPlayer) {
				EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass((EntityPlayer) damager);
				if (rpgclass == EnumRpgClass.BERSERKER || rpgclass == EnumRpgClass.SHIELDEDBERSERKER) {
					evt.ammount += 2;
				}
			}
		}
		if (evt.entityLiving != null && evt.entityLiving instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) evt.entityLiving;
			EnumRpgClass rpgclass = EnumRpgClass.getPlayerClass(player);
			if (rpgclass == null) {
				return;
			}
			RpgInventory inv = mod_RpgInventory.proxy.getInventory(player.username);
			ItemStack var3 = player.inventory.armorItemInSlot(3);
			ItemStack var2 = player.inventory.armorItemInSlot(2);
			ItemStack var1 = player.inventory.armorItemInSlot(1);
			ItemStack var0 = player.inventory.armorItemInSlot(0);
			Item item;
			Item item1;
			Item item2;
			Item item3;
			if (inv.getGloves() != null && inv.getGloves().getItem() == mod_RpgInventory.glovesem) {
				if (((float) evt.ammount * 0.2F) < 1) {
					evt.ammount -= 1;
				} else {
					evt.ammount -= MathHelper.floor_float((float) evt.ammount * 0.2F);
				}
			}
			if (var0 != null && var1 != null && var2 != null && var3 != null) {
				item = var3.getItem();
				item1 = var2.getItem();
				item2 = var1.getItem();
				item3 = var0.getItem();
				if (item != null && item1 != null && item2 != null && item3 != null) {
					if (inv != null) {
						ItemStack shield = inv.getShield();
						if (shield != null)
						{
							if (rpgclass == EnumRpgClass.SHIELDEDMAGE) {
								float damageReduction = 0.20F;
								EntityLiving damagedealer = null;
								if (evt.source.isMagicDamage()) {
									damageReduction = 0.50F;
								} else if (evt.source.getSourceOfDamage() != null) {
									if (evt.source.isProjectile()) {
										if (evt.source.getSourceOfDamage() instanceof EntityArrow) {
											if (((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity != null) {
												if (((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity instanceof EntityLiving) {
													damagedealer = (EntityLiving) ((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity;
												}
											}
										}
										if (evt.source.getSourceOfDamage() instanceof EntityLiving) {
											damagedealer = (EntityLiving) evt.source.getSourceOfDamage();
										}
									}
								}
								if (damagedealer != null) {
									if (damagedealer.isEntityUndead()) {
										damageReduction = 0.75F;
									}
								}
								evt.ammount -= MathHelper.floor_float(((float) evt.ammount) * damageReduction);
								damageItem(shield, inv, player, 1, 1);

							} else if (rpgclass == EnumRpgClass.SHIELDEDARCHER) {
								float damageReduction = 0.25F;
								EntityLiving damagedealer = null;
								if (evt.source.getSourceOfDamage() != null) {
									if (evt.source.isProjectile()) {
										if (evt.source.getSourceOfDamage() instanceof EntityArrow) {
											if (((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity != null) {
												if (((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity instanceof EntityLiving) {
													damagedealer = (EntityLiving) ((EntityArrow) evt.source.getSourceOfDamage()).shootingEntity;
													damageReduction = 0.70F;
												}
											}
										}
										if (evt.source.getSourceOfDamage() instanceof EntityLiving) {
											damagedealer = (EntityLiving) evt.source.getSourceOfDamage();
										}
									}
								}
								if (damageReduction < 0.70F) {
									if (damagedealer != null) {
										if (damagedealer.getCreatureAttribute() == EnumCreatureAttribute.ARTHROPOD) {
											damageReduction = 0.40F;
										}
										if (damagedealer instanceof EntityTameable) {
											if (!damagedealer.isEntityUndead()) {
												damageReduction = 0.50F;
											}
										}
									}
								}

								if (evt.source.isFireDamage()) {
									evt.ammount += MathHelper.floor_float(((float) evt.ammount) * 0.10F);
								} else {
									evt.ammount -= MathHelper.floor_float(((float) evt.ammount) * damageReduction);
								}
								damageItem(shield, inv, player, 1, 1);
							}
						} else if (rpgclass == EnumRpgClass.SHIELDEDBERSERKER) {
							float damageReduction = 0.50F;
							evt.ammount -= MathHelper.floor_float(((float) evt.ammount) * damageReduction);
							if (player.carryoverDamage > 0 && player.carryoverDamage < 1) {
								System.out.println(player.carryoverDamage);
								player.carryoverDamage = 0;
							} else if (player.carryoverDamage > 0) {
								player.carryoverDamage--;
							}
							if (evt.ammount >= 2) {
								evt.ammount -= 1;
							}
							damageItem(shield, inv, player, 1, 1);
						}
					}
				}
			}
		}

	}

	public void damageItem(ItemStack item, RpgInventory inv, EntityPlayer p, int slot, int amount) {
		if (item.getItemDamage() + amount >= item.getMaxDamage()) {
			//Trigger item break stuff
			item = null;
		} else {
			item.damageItem(amount, p);
		}
		inv.setInventorySlotContents(slot, item);
	}
}
