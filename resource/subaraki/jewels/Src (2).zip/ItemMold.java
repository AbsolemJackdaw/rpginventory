package RpgInventory;

import net.minecraft.item.Item;



public class ItemMold extends Item {

	public ItemMold(int par1) {
		super(par1);
	}
	
	public String getTextureFile()
	{
		return "/subaraki/RPGinventoryTM.png";
	}
}
